/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,n,largest;
    n=5;
    int array[n];
    printf("enter the array:");
    for(i=1;i<=n;i++){
        scanf("%d",&array[i]);
    }
    largest=array[0];
    for(j=1;j<=n;j++)
    {
        if(largest<array[j])
        {
            largest = array[j];
            
        }
        
    }
    printf("The largest number is %d",largest);
}
    
    
    
    
//   int array[6] = {12,56,78,32,42,18};
//     largest=array[0];
//     for(i=1;i<=6;i++){
//         if(largest>array[i]){
//             largest=array[i];
//         }
//         printf("The largest element in the array %d",largest);
//         return 0;
//         }
// }




