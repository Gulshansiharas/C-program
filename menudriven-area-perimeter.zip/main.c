/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
char c;
    int choice,l=7,b=2,area,perim,area1,perim1,area2,perim2,area3,perim3,r=2,a=5,h=3;
    do{
        printf("\n1. Print Area of Rectangle\n2. Print Perimeter of Rectangle\n3. Print Area of Square\n4. Print Perimeter of Square\n5.Print Area of Circle\n6.Print Perimeter of Circle\n6.Print Area of Triangle\n7.Print Perimeter of Triangle\n8.Exit\n");
        scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        area=a*b;
        printf("The area of a rectangle is:%d\n",area);
        break;
        case 2:
        perim=2*(a+b);
        printf("The perimeter of a rectangle is:%d\n",perim);
        break;
         case 3:
        area1=a*a;
        printf("The area of a square is:%d\n",area1);
        break;
         case 4:
        perim1=4*a;
        printf("The perimeter of a squareis:%d\n",perim1);
        break;
         case 5:
        area2=3.14*r*r;
        printf("The area of a circle is:%d\n",area2);
        break;
        case 6:
        perim2=2*3.14*r;
        printf("The perimeter of a circle is:%d\n",perim2);
        break;
        case 7:
        area3=1/2*b*l;
        printf("The area of a triangle is:%d\n",area3);
        break;
        case 8:
        perim3=l+b+h;
        printf("The perimeter of a triangle is:%d\n",perim1);
        break;
        case 9:
        exit(0);
        break;
        default:
        printf("please enter the valid choice\n");
    }
    printf("do you want to enter more?(y/n)\n");
    scanf("%s",&c);
    }while(c=='y'||c=='Y');
return 0;
}






