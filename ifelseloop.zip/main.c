/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int h;
    printf("Enter the number:");
    scanf("%d",&h);
    if(h==1){
        printf("Monday");
    }
    else if(h==2){
        printf("Tuesday");
    }
    else if(h==3){
        printf("Wednesday");
    }
    else if(h==4){
        printf("Thursday");
    }
    else if(h==5){
        printf("Friday");
    }
    else if(h==6){
        printf("Saturday");
    }
    else if(h==7){
        printf("Sunday");
    }
    else{
        printf("Invalid choice");
    }
    

    return 0;
}
