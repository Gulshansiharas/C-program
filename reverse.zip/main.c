/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

// int main()
// {
//     int n,d,new,temp;
//     printf("Enter the number:");
//     scanf("%d",&n);
//     new=0;
//     temp=n;
//     while(n>0)
//     {
//      d=n%10;
//      new=new*10+d;
//      n/=10;
//     }
//     if(temp == new)
//     {
//     printf("palindrome");
//     }
//     else{
//     printf("Not palindrome");
//     }
//   return 0;  
// }
        
    
    
    
    
    
    








